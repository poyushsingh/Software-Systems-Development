1. I have implemted kaooa game using HTML,CSS,JAVASCRIPT and Tilt.js.
2. I have implemted Drag and Drop events using HTML and JAVASCRIT.
3. Drawn star board using svg,line tag and circle tag.
4. Used 2 Maps to keep track of which crow present at which position inside board.
5. Each position inside star board is labeled from top to bottom with top circle being labeled as div_c1 and last circle being labeled as div_c10.
6. Each crow from 1 to 7 is labelled as crow1,crow2,.....,crow7 and denoted by Green circle.
7. Vulture is labelled as vulture and denoted by red circle.

#Assumptions:-

1. User will have an active Internet Conection.
2. User Knows the rules related to game.
3. Red circle denotes VULTURE and Green Circle denotes CROWS.
4. All files/images which is present inside this folder will be present while running the program.
5. After finishing user will select anyone option displayed in the pop-up window.

#Capture and Log Mouse Events in a file:-

1. I have captured only legal moves played by the user.
   what are legal moves?
   1. Dragging Crow/Vulture from Bench to particular circle inside star board.(Bench-It is the position where all Crows and Vultute will be present at the start of the Game.)
   2. Dragging Crow/Vulture from one circle position to other circle position inside star Board.
2. Log File format : [Date-time] [Moved <crow> from <starting-position> to <ending-position>]
3. For Downloading Log file click on Download button or after finishing of game user will be given choice to download log file or restart the game.
4. last Entry in Log File is the Winner of the Game.

#How to Run:-
Just open index.html with live server and internet connection.
