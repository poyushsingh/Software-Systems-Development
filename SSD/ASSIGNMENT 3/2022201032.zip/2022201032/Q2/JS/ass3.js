let which_crow
let which_div_circle
let vulture_kill_cnt=0
let chance="0"    //0->crow , 1->vulture
let crow_cnt=0     //crows should not move untill all 7 crows are not on board.

let map=new Map();  //stores which crow is present at which div
map.set("div_c1","0");
map.set("div_c2","0"); 
map.set("div_c3","0");
map.set("div_c4","0");
map.set("div_c5","0");
map.set("div_c6","0"); 
map.set("div_c7","0");
map.set("div_c8","0");
map.set("div_c9","0");
map.set("div_c10","0");

let map_inside_star=new Map();  //stores if crow is in board or not and if present then on which board
map_inside_star.set("crow1","0")
map_inside_star.set("crow2","0")
map_inside_star.set("crow3","0")
map_inside_star.set("crow4","0")
map_inside_star.set("crow5","0")
map_inside_star.set("crow6","0")
map_inside_star.set("crow7","0")
map_inside_star.set("vulture","0")

var txt=[]

document.getElementById('link').onclick = function(code) {
    txt = txt.toString();
    txt = txt.replace(/,/g,"")
    this.href = 'data:text/plain;charset=utf-11,' + encodeURIComponent(txt);
};

function adjacent(s1,s2){       //calculates adjacent of each div on board
    if(s1=="div_c1"){
        if(s2=="div_c3" || s2=="div_c4"){
            return true;
        }
        else{
            return false;
        }   
    }

    if(s1=="div_c2"){
        if(s2=="div_c3" || s2=="div_c6"){
            return true;
        }
        else{
            return false;
        }   
    }

    if(s1=="div_c3"){
        if(s2=="div_c1" || s2=="div_c2" || s2=="div_c4" || s2=="div_c6"){
            return true;
        }
        else{
            return false;
        }   
    }

    if(s1=="div_c4"){
        if(s2=="div_c1" || s2=="div_c3" || s2=="div_c5" || s2=="div_c7"){
            return true;
        }
        else{
            return false;
        }   
    }

    if(s1=="div_c5"){
        if(s2=="div_c4" || s2=="div_c7"){
            return true;
        }
        else{
            return false;
        }   
    }

    if(s1=="div_c6"){
        if(s2=="div_c2" || s2=="div_c3" || s2=="div_c8" || s2=="div_c9"){
            return true;
        }
        else{
            return false;
        }   
    }

    if(s1=="div_c7"){
        if(s2=="div_c4" || s2=="div_c5" || s2=="div_c8" || s2=="div_c10"){
            return true;
        }
        else{
            return false;
        }   
    }

    if(s1=="div_c8"){
        if(s2=="div_c6" || s2=="div_c7" || s2=="div_c9" || s2=="div_c10"){
            return true;
        }
        else{
            return false;
        }   
    }

    if(s1=="div_c9"){
        if(s2=="div_c6" || s2=="div_c8"){
            return true;
        }
        else{
            return false;
        }   
    }

    if(s1=="div_c10"){
        if(s2=="div_c7" || s2=="div_c8"){
            return true;
        }
        else{
            return false;
        }   
    }
}


function reset_helper(s1){
    console.log(`s1 - ${s1}`)
    // console.log(`who dead - ${map.get(s1)}`)
    let tmp=map.get(s1)
    map_inside_star.set(tmp,"0");
    map.set(s1,"0");
    document.getElementById(tmp).remove();
    vulture_kill_cnt++;
    console.log(`vulture_kill_cnt - ${vulture_kill_cnt}`);
    const d = new Date();
    txt.push(d)
    txt.push(` Vulture Killed !!! \n`)
    const tmpo=document.getElementById("dead").innerHTML=`Dead Crow count :- ${vulture_kill_cnt}`

}


function who_wins(){                //checks win condition
    console.log("who_wins_called..")
    if(vulture_kill_cnt>=4){
        const d = new Date();
        txt.push(d)
        txt.push(" VULTURE WINS !!! ")
        swal.fire({  
            title: 'VULTURE WINS!!!!',  
            showDenyButton: true, 
            confirmButtonText: `Restart`,  
            denyButtonText: `Download file and Restart`,
          }).then((result) => {  
              if (result.isConfirmed) {    
                window.location.reload();
              } else if (result.isDenied) {    
                document.getElementById("link").click();
                window.location.reload();
               }
          });

    }
    else{
        let pos_vulture=map_inside_star.get("vulture")
        if(pos_vulture=="div_c1"){
            if(map.get("div_c3")!=0 && map.get("div_c4")!=0 && map.get("div_c6")!=0 && map.get("div_c7")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    }
                });
            }
        }
        if(pos_vulture=="div_c2"){
            if(map.get("div_c3")!=0 && map.get("div_c6")!=0 && map.get("div_c4")!=0 && map.get("div_c8")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    } 
                });
            }
        }
        if(pos_vulture=="div_c3"){
            if(map.get("div_c1")!=0 && map.get("div_c2")!=0 && map.get("div_c4")!=0 && map.get("div_c6")!=0 && map.get("div_c9")!=0 && map.get("div_c5")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    }
                });
            }
        }
        if(pos_vulture=="div_c4"){
            if(map.get("div_c1")!=0 && map.get("div_c3")!=0 && map.get("div_c5")!=0 && map.get("div_c7")!=0 && map.get("div_c2")!=0 && map.get("div_c10")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    }
                });
            }
        }
        if(pos_vulture=="div_c5"){
            if(map.get("div_c4")!=0 && map.get("div_c7")!=0 && map.get("div_c8")!=0 && map.get("div_c3")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    }
                });
            }
        }
        if(pos_vulture=="div_c6"){
            if(map.get("div_c2")!=0 && map.get("div_c3")!=0 && map.get("div_c8")!=0 && map.get("div_c9")!=0 && map.get("div_c1")!=0 && map.get("div_c10")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    }
                });
            }
        }
        if(pos_vulture=="div_c7"){
            if(map.get("div_c4")!=0 && map.get("div_c5")!=0 && map.get("div_c8")!=0 && map.get("div_c10")!=0 && map.get("div_c1")!=0 && map.get("div_c9")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    }
                });
            }
        }
        if(pos_vulture=="div_c8"){
            if(map.get("div_c6")!=0 && map.get("div_c7")!=0 && map.get("div_c9")!=0 && map.get("div_c10")!=0 && map.get("div_c5")!=0 && map.get("div_c2")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    }
                });
            }
        }
        if(pos_vulture=="div_c9"){
            if(map.get("div_c6")!=0 && map.get("div_c8")!=0 && map.get("div_c7")!=0 && map.get("div_c3")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    }
                });
            }
        }
        if(pos_vulture=="div_c10"){
            if(map.get("div_c7")!=0 && map.get("div_c8")!=0 && map.get("div_c6")!=0 && map.get("div_c4")!=0){
                const d = new Date();
                txt.push(d)
                txt.push(" CROW WINS !!! ")
                swal.fire({  
                    title: 'CROW WINS!!!!',  
                    showDenyButton: true,   
                    confirmButtonText: `Restart`,  
                    denyButtonText: `Download file and Restart`,
                }).then((result) => {  
                    if (result.isConfirmed) {    
                        window.location.reload();
                    } else if (result.isDenied) {    
                        document.getElementById("link").click();
                        window.location.reload();
                    }
                });
            }
        }

    }
}

function helper_force_move(root,s1,s2,s3,s4,leaf,c1="1",c2="2"){
    let flag=0
    console.log(`inside helper force move`)
    console.log(`root - ${root}`)
    console.log(`s1 - ${s1}`)
    console.log(`s2 - ${s2}`)
    console.log(`s3 - ${s3}`)
    console.log(`s4 - ${s4}`)
    console.log(`leaf - ${leaf}`)
    console.log(`c1 - ${c1}`)
    console.log(`c2 - ${c2}`)

        if(map.get(s1) == "0"){
            if(map.get(s2) == "0"){
                if(map.get(s3) == "0"){
                    if(map.get(s4) == "0"){
                        if(c1=="1" && c2=="2"){
                            //its a corner node
                            if(leaf==s1 || leaf==s2){
                                flag=1
                                return true
                            }
                        }
                        else if(c1!="1" && c2!="2"){
                            //middle node
                            if(leaf==s1 || leaf==s2 || leaf==c1 || leaf==c2){
                                flag=1
                                return true
                            }
                        }
                        else{
                            return false
                        }
                    }
                    else{
                        if(c1=="1" && c2=="2"){
                            //its a corner node
                            if(leaf==s1 || leaf==s2){
                                flag=1
                                return true
                            }
                        }
                        else if(c1!="1" && c2!="2"){
                            //middle node
                            if(leaf==s1 || leaf==s2 || leaf==c1 || leaf==c2){
                                flag=1
                                return true
                            }
                        }
                        else{
                            return false
                        }
                    }
                }
                else{
                    if(map.get(s4) == "0"){
                        if(c1=="1" && c2=="2"){
                            //its a corner node
                            if(leaf==s1 || leaf==s2){
                                flag=1
                                return true
                            }
                        }
                        else if(c1!="1" && c2!="2"){
                            //middle node
                            if(leaf==s1 || leaf==s2 || leaf==c1 || leaf==c2){
                                flag=1
                                return true
                            }
                        }
                        else{
                            return false
                        }
 
                    }
                    else{
                        if(c1=="1" && c2=="2"){
                            //its a corner node
                            if(leaf==s1 || leaf==s2){
                                flag=1
                                return true
                            }
                        }
                        else if(c1!="1" && c2!="2"){
                            //middle node
                            if(leaf==s1 || leaf==s2 || leaf==c1 || leaf==c2){
                                flag=1
                                return true
                            }
                        }
                        else{
                            return false
                        }

                    }
                }
            }
            else{
                if(map.get(s3) == "0"){
                    if(map.get(s4) == "0"){
                        if(leaf == s4){
                            reset_helper(s2)
                            flag=1
                            return true
                        }
                        else{
                            return false
                        }
                    }
                    else{
                        if(c1=="1" && c2=="2"){
                            //its a corner node
                            if(leaf==s1 ){
                                flag=1
                                return true
                            }
                        }
                        else if(c1!="1" && c2!="2"){
                            //middle node
                            if(leaf==s1 || leaf==c1 || leaf==c2){
                                flag=1
                                return true
                            }
                        }
                        else{
                            return false
                        }

                    }
                }
                else{
                    if(map.get(s4) == "0"){
                        //10
                        if(leaf == s4){
                            reset_helper(s2)
                            flag=1
                            return true
                        }
                        else{
                            return false
                        }
                    }
                    else{
                        //11
                        if(c1=="1" && c2=="2"){
                            //its a corner node
                            if(leaf==s1){
                                flag=1
                                return true
                            }
                        }
                        else if(c1!="1" && c2!="2"){
                            //middle node
                            if(leaf==s1 || leaf==c1 || leaf==c2){
                                flag=1
                                return true
                            }
                        }
                        else{
                            return false
                        }

                    }
                }
            }

        }
        else{
            if(map.get(s2) == "0"){
                if(map.get(s3) == "0"){
                    if(map.get(s4) == "0"){
                        //1000
                        if(leaf == s3){
                            reset_helper(s1)
                            flag=1
                            return true
                        }
                        else{
                            return false
                        }
                    }
                    else{
                        //1001
                        if(leaf == s3){
                            reset_helper(s1)
                            flag=1
                            return true
                        }
                        else{
                            return false
                        }
                    }
                }
                else{
                    if(map.get(s4) == "0"){
                        //1010
                        if(c1=="1" && c2=="2"){
                            //its a corner node
                            if(leaf==s2){
                                flag=1
                                return true
                            }
                        }
                        else if(c1!="1" && c2!="2"){
                            //middle node
                            if(leaf==s2 || leaf==c1 || leaf==c2){
                                flag=1
                                return true
                            }
                        }
                        else{
                            return false
                        }

                    }
                    else{
                        //1011
                        if(c1=="1" && c2=="2"){
                            //its a corner node
                            if(leaf==s2){
                                flag=1
                                return true
                            }
                        }
                        else if(c1!="1" && c2!="2"){
                            //middle node
                            if(leaf==s2 || leaf==c1 || leaf==c2){
                                flag=1
                                return true
                            }
                        }
                        else{
                            return false
                        }

                    }
                }
            }
            else{
                //11
                if(map.get(s3) == "0"){
                    if(map.get(s4) == "0"){
                        //1100
                        if(leaf == s3){
                            reset_helper(s1);
                            flag=1
                            return true;
                        }
                        else if(leaf == s4){
                            reset_helper(s2);
                            flag=1
                            return true;
                        }
                        else{
                            return false
                        }
                    }
                    else{
                        //1101
                        if(leaf == s3){
                            reset_helper(s1)
                            flag=1
                            return true
                        }
                        else{
                            return false
                        }
                    }
                }
                else{
                    if(map.get(s4) == "0"){
                        //1110
                        if(leaf == s4){
                            reset_helper(s2)
                            flag=1
                            return true
                        }
                        else{
                            return false
                        }
                    }
                    else{
                        //1111
                        if(c1=="1" && c2=="2"){
                            //its a corner node
                            return true
                        }
                        else if(c1!="1" && c2!="2"){
                            //middle node
                            if(leaf==c1 || leaf==c2){
                                flag=1
                                return true
                            }
                        }
                        else{
                            return false
                        }
                    }
                }
            }
        }
}

function force_move(s1,s2){
    console.log("inside force_move")
    console.log(`s1 - ${s1}`)
    console.log(`s2 - ${s2}`)
    if(s1=="div_c1"){
        return helper_force_move("div_c1","div_c3","div_c4","div_c6","div_c7",s2);
    }
    else if(s1=="div_c2"){
        return helper_force_move("div_c2","div_c6","div_c3","div_c8","div_c4",s2);
    }
    else if(s1=="div_c3"){
        return helper_force_move("div_c3","div_c6","div_c4","div_c9","div_c5",s2,"div_c1","div_c2");
    }
    else if(s1=="div_c4"){
        return helper_force_move("div_c4","div_c3","div_c7","div_c2","div_c10",s2,"div_c1","div_c5");
    }
    else if(s1=="div_c5"){
        return helper_force_move("div_c5","div_c4","div_c7","div_c3","div_c8",s2);
    }
    else if(s1=="div_c6"){
        return helper_force_move("div_c6","div_c8","div_c3","div_c10","div_c1",s2,"div_c2","div_c9");
    }
    else if(s1=="div_c7"){
        return helper_force_move("div_c7","div_c4","div_c8","div_c1","div_c9",s2,"div_c5","div_c10");
    }
    else if(s1=="div_c8"){
        return helper_force_move("div_c8","div_c7","div_c6","div_c5","div_c2",s2,"div_c9","div_c10");
    }
    else if(s1=="div_c9"){
        return helper_force_move("div_c9","div_c8","div_c6","div_c7","div_c3",s2);
    }
    else if(s1=="div_c10"){
        return helper_force_move("div_c10","div_c7","div_c8","div_c4","div_c6",s2);
    }

    }

(function() {
    var dragged, listener;

    console.clear();

    dragged = null;

    listener = document.addEventListener;

    listener("dragstart", (event) => {
      which_crow=event.target.id
      console.log(which_crow);

      return dragged = event.target;
    });

    listener("dragend", (event) => {

    });

    listener("dragover", function(event) {
      return event.preventDefault();
    });


    listener("drop", (event) => {
      which_div_circle=event.target.id

      if(map_inside_star.get(which_crow)=="0" && ((which_crow=="vulture" && chance=="1") || (which_crow!="vulture" && chance=="0"))){
            if(map.get(which_div_circle) == "0"){
                map.set(which_div_circle,which_crow)
                if(map_inside_star.get(which_crow)!="0"){
                    const tmp=map_inside_star.get(which_crow)
                    map.set(tmp,"0")
                    map_inside_star.set(which_crow,"0");
                }
                
            }
            map_inside_star.set(which_crow,which_div_circle);
            console.log(map)
            console.log(map_inside_star)
            
            event.preventDefault();
            if (event.target.className === "dropzone") {
                dragged.parentNode.removeChild(dragged);
                event.target.appendChild(dragged);
                if(chance=="1"){
                    chance="0"
                }
                else if(chance=="0"){
                    chance="1"
                }
                if(which_crow!="vulture"){
                    crow_cnt++
                }
                console.log(`in 1 - ${chance}`)
                console.log(`crow_cnt - ${crow_cnt}`)

                let step1=(` Moved ${which_crow} from bench to ${which_div_circle}\n`)
                const d = new Date();
                txt.push(d)
                txt.push(step1)
                console.log(step1)
                if(chance=="0"){
                    //crow
                    const tmpoe=document.getElementById("turn").innerHTML=`Who's Turn :- CROW`
                }
                else{
                    const tmpoe=document.getElementById("turn").innerHTML=`Who's Turn :- VULTURE`
                }
                who_wins();
                return;
            }
        }
        else{
            let pos2
            if(which_crow=="vulture" && chance=="1"){
                if(force_move(map_inside_star.get(which_crow),which_div_circle)){
                    console.log(`--------------------------------`)
                        if(map.get(which_div_circle) == "0"){
                            pos2=map_inside_star.get(which_crow)

                            map.set(which_div_circle,which_crow)
                            if(map_inside_star.get(which_crow)!="0"){
                                const tmp=map_inside_star.get(which_crow)
                                map.set(tmp,"0")
                                map_inside_star.set(which_crow,"0");
                            }
                        }
                        map_inside_star.set(which_crow,which_div_circle);

                        console.log(map)
                        console.log(map_inside_star)
                        event.preventDefault();
                        if (event.target.className === "dropzone") {
                            // console.log(`///////////////////////////`)
                            dragged.parentNode.removeChild(dragged);
                            event.target.appendChild(dragged);

                            chance="0"
                            console.log(`in 2 - ${chance}`)
                            
                            let step2=(` Moved ${which_crow} from ${pos2} to ${which_div_circle}\n`)
                            const d = new Date();
                            txt.push(d)
                            txt.push(step2)
                            console.log("--------------------",step2)
                            if(chance=="0"){
                                //crow
                                const tmpoe=document.getElementById("turn").innerHTML=`Who's Turn :- CROW`
                            }
                            else{
                                const tmpoe=document.getElementById("turn").innerHTML=`Who's Turn :- VULTURE`
                            }

                            who_wins();
                            return;
                        }
                    // }
   
                }
                
            }
            //crow
            if(adjacent(map_inside_star.get(which_crow),which_div_circle) && which_crow!="vulture" && chance=="0" && crow_cnt>6){
                let pos5
                if(map.get(which_div_circle) == "0"){
                    pos5=map_inside_star.get(which_crow)
                    map.set(which_div_circle,which_crow)
                    if(map_inside_star.get(which_crow)!="0"){
                        const tmp=map_inside_star.get(which_crow)
                        map.set(tmp,"0")
                        map_inside_star.set(which_crow,"0");
                    }
                    
                }
                map_inside_star.set(which_crow,which_div_circle);
                console.log(map)
                console.log(map_inside_star)
                
                event.preventDefault();
                if (event.target.className === "dropzone") {
                    dragged.parentNode.removeChild(dragged);
                    event.target.appendChild(dragged);

                    chance="1"
                    console.log(`in 4 - ${chance}`)

                    let step5=(` Moved ${which_crow} from ${pos5} to ${which_div_circle}\n`)
                    const d = new Date();
                    txt.push(d)
                    txt.push(step5)
                    console.log("--------------------",step5)
                    if(chance=="0"){
                        //crow
                        const tmpoe=document.getElementById("turn").innerHTML=`Who's Turn :- CROW`
                    }
                    else{
                        const tmpoe=document.getElementById("turn").innerHTML=`Who's Turn :- VULTURE`
                    }

                    who_wins();
                    return;
                }
            }
        }
    });

  }).call(this);