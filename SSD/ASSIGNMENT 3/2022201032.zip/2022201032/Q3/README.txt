#Assumptions:-

1. User will have an active Internet Conection.
2. Sometimes API will not be able to fetch images or Articles related to particular News.

#Summary:-

1. Ceated News website using html,css,javascript and bootstrap which populate advertisement at top and bottom and feeds recent news .
2. I have created a Navbar which has 7 tabs General,Technology,Sport,Business,Health,Science and Entertainment.
3. User will click on his/her preferred choice and the news related to that particular area will be shown on the main screen.
4. I have used promise call while fetching data from API using promise and async .
5. If status of Fetched data is between 200 and 300 (i.e OK )then there is no error and our news has been successfully fetched else error.

What is really happening?

1. User will land on a General page (Home page) of website.
2. User can click on a particular tab from Navbar.
3. The API related to that particular field will be called and the returned data from API will get stored in array (named as arr_for_news) .
4. If promise resolves ,then Display function will be called and the content inside arr_for_news will be shown on the screen.
5. If promise rejects ,then "Error !!" will be thrown on console log.

#How to Run:-
Just open index.html with live server and internet connection.
