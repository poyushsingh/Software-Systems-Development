let general_btn=document.getElementById("general")
let sport_btn=document.getElementById("sport")
let technology_btn=document.getElementById("technology")
let entertainment_btn=document.getElementById("entertainment")
let science_btn=document.getElementById("science")
let health_btn=document.getElementById("health")
let business_btn=document.getElementById("business")
 
let newstype_btn=document.getElementById("newstype")
let newsdetails_btn=document.getElementById("newsdetails")
 
//array
let arr_for_news = [];

async function fetch_Headlines(){
    let data=await fetch(headline_api);
    arr_for_news=[]
    if(data.status >=200 && data.status <300){
        let result=await data.json();
        console.log(result.articles)
        arr_for_news=result.articles;
    }
    else{
        //error
        console.log("Error !!")
    }

    display_news();
    
}

let mypromise_sport="";
async function fetch_sport_news(){
    mypromise_sport=new Promise(async function(resolve,reject){
        let data=await fetch(sport_api);
        arr_for_news=[]
        if(data.status >=200 && data.status <300){
            let result=await data.json();
            // console.log(result.articles)
            arr_for_news=result.articles;
            resolve();
        }
        else{
            //error
            reject();
        }
    })
}

// async function fetch_sport_news(){
//     let data=await fetch(sport_api);
//     arr_for_news=[]
//     if(data.status >=200 && data.status <300){
//         let result=await data.json();
//         console.log(result)
//         arr_for_news=result.articles
//     }
//     else{
//         //error
//     }

//     display_news();
    
// }

let mypromise_technology="";
async function fetch_technology_news(){
    mypromise_technology=new Promise(async function(resolve,reject){
        let data=await fetch(technology_api);
        arr_for_news=[]
        if(data.status >=200 && data.status <300){
            let result=await data.json();
            // console.log(result.articles)
            arr_for_news=result.articles;
            resolve();
        }
        else{
            //error
            reject();
        }
    })
}



// async function fetch_technology_news(){
//     let data=await fetch(technology_api);
//     arr_for_news=[]
//     if(data.status >=200 && data.status <300){
//         let result=await data.json();
//         console.log(result)
//         arr_for_news=result.articles
//     }
//     else{
//         //error
//     }

//     display_news();
    
// }

let mypromise_business="";
async function fetch_business_news(){
    mypromise_business=new Promise(async function(resolve,reject){
        let data=await fetch(business_api);
        arr_for_news=[]
        if(data.status >=200 && data.status <300){
            let result=await data.json();
            // console.log(result.articles)
            arr_for_news=result.articles;
            resolve();
        }
        else{
            //error
            reject();
        }
    })
}

// async function fetch_business_news(){
//     let data=await fetch(business_api);
//     arr_for_news=[]
//     if(data.status >=200 && data.status <300){
//         let result=await data.json();
//         console.log(result)
//         arr_for_news=result.articles
//     }
//     else{
//         //error
//     }

//     display_news();
    
// }

let mypromise_science="";
async function fetch_science_news(){
    mypromise_science=new Promise(async function(resolve,reject){
        let data=await fetch(science_api);
        arr_for_news=[]
        if(data.status >=200 && data.status <300){
            let result=await data.json();
            // console.log(result.articles)
            arr_for_news=result.articles;
            resolve();
        }
        else{
            //error
            reject();
        }
    })
}

let mypromise_entertainment="";
async function fetch_entertainment_news(){
    mypromise_entertainment=new Promise(async function(resolve,reject){
        let data=await fetch(entertainment_api);
        arr_for_news=[]
        if(data.status >=200 && data.status <300){
            let result=await data.json();
            // console.log(result.articles)
            arr_for_news=result.articles;
            resolve();
        }
        else{
            //error
            reject();
        }
    })
}

let mypromise_health="";
async function fetch_health_news(){
    mypromise_health=new Promise(async function(resolve,reject){
        let data=await fetch(health_api);
        arr_for_news=[]
        if(data.status >=200 && data.status <300){
            let result=await data.json();
            // console.log(result.articles)
            arr_for_news=result.articles;
            resolve();
        }
        else{
            //error
            reject();
        }
    })
}

function display_news(){
    newsdetails_btn.innerHTML=" "
    if(arr_for_news.length==0){
        newsdetails_btn.innerHTML="<h3> not found</h3>"
        return;
    }

    for(let i=0;i<arr_for_news.length;i++){

        var date=arr_for_news[i].publishedAt.split("T")

        var col=document.createElement('div');
        col.className="col-sm-12 col-md-4 col-lg-3 p-2 card"

        var card=document.createElement('div');
        card.className="p-2"

        var image=document.createElement('img');
        image.setAttribute("height","matchparent")
        image.setAttribute("width","100%")
        image.src=arr_for_news[i].urlToImage;

        var cardbody=document.createElement('div');

        var newsheading=document.createElement("h5")
        newsheading.className="card-title";
        newsheading.innerHTML=arr_for_news[i].title;

        var dateheading=document.createElement("h6");
        dateheading.className="text-primary";
        dateheading.innerHTML=date[0];

        var discription=document.createElement('p')
        discription.className="text-muted";
        discription.innerHTML=arr_for_news[i].description

        var link=document.createElement('a')
        link.className="btn btn-dark"
        link.setAttribute("target","_blank")
        link.href=arr_for_news[i].url
        link.innerHTML="Read more"

        cardbody.appendChild(newsheading)
        cardbody.appendChild(dateheading)
        cardbody.appendChild(discription)
        cardbody.appendChild(link)
        // cardbody.appendChild(ads)

        card.appendChild(image);
        card.appendChild(cardbody)

        col.appendChild(card)


        newsdetails_btn.appendChild(col)

    }
     
}

window.onload=function(){
    newstype_btn.innerHTML="<h4>Headlines</h4>"
    fetch_Headlines();
    
};




//APIs
const api_key="47e78c604ce14dcca8130940f3cd011d"
const headline_api = "https://newsapi.org/v2/top-headlines?country=in&apiKey=47e78c604ce14dcca8130940f3cd011d";
const general_api="https://newsapi.org/v2/top-headlines?country=in&category=general&apiKey=47e78c604ce14dcca8130940f3cd011d"
const sport_api="https://newsapi.org/v2/top-headlines?country=in&category=sports&apiKey=47e78c604ce14dcca8130940f3cd011d"
const technology_api="https://newsapi.org/v2/top-headlines?country=in&category=technology&apiKey=47e78c604ce14dcca8130940f3cd011d"
const business_api="https://newsapi.org/v2/top-headlines?country=in&category=business&apiKey=47e78c604ce14dcca8130940f3cd011d"
const health_api="https://newsapi.org/v2/top-headlines?country=in&category=health&apiKey=47e78c604ce14dcca8130940f3cd011d"
const science_api="https://newsapi.org/v2/top-headlines?country=in&category=science&apiKey=47e78c604ce14dcca8130940f3cd011d"
const entertainment_api="https://newsapi.org/v2/top-headlines?country=in&category=entertainment&apiKey=47e78c604ce14dcca8130940f3cd011d"

general_btn.addEventListener("click",function(){
    newstype_btn.innerHTML="<h4>General News</h4>"
    fetch_Headlines();

})

sport_btn.addEventListener("click",function(){
    newstype_btn.innerHTML="<h4>Sport News</h4>"
    fetch_sport_news()
    mypromise_sport.then(display_news()).catch(console.log("Error !!"))
})

technology_btn.addEventListener("click",function(){
    newstype_btn.innerHTML="<h4>Technology News</h4>"
    fetch_technology_news()
    mypromise_technology.then(display_news()).catch(console.log("Error !!"))
})

business_btn.addEventListener("click",function(){
    newstype_btn.innerHTML="<h4>Business News</h4>"
    fetch_business_news()
    mypromise_business.then(display_news()).catch(console.log("Error !!"))
})

science_btn.addEventListener("click",function(){
    newstype_btn.innerHTML="<h4>Science News</h4>"
    fetch_science_news()
    mypromise_science.then(display_news()).catch(console.log("Error !!"))
})

entertainment_btn.addEventListener("click",function(){
    newstype_btn.innerHTML="<h4>Entertainment News</h4>"
    fetch_entertainment_news()
    mypromise_entertainment.then(display_news()).catch(console.log("Error !!"))
})

health_btn.addEventListener("click",function(){
    newstype_btn.innerHTML="<h4>Health News</h4>"
    fetch_health_news()
    mypromise_health.then(display_news()).catch(console.log("Error !!"))
})

