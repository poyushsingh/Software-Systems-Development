use SSD_ASSIGNMENT_2;
DROP PROCEDURE IF EXISTS bulid_PersonTransfer;

DELIMITER //
CREATE PROCEDURE `bulid_PersonTransfer`()
BEGIN
    
	CREATE table if not exists PersonTransfer(
	PT int auto_increment NOT NULL PRIMARY KEY, 
	EmpID int , 
	FirstName varchar(255),
	LastName varchar(255),
        Gender varchar(10),
        DateofJoining date, 
        CurrentRegion varchar(25),
        NewRegion varchar(255),
        FOREIGN KEY (EmpID) REFERENCES person(Emp_ID)
    );
    truncate table PersonTransfer;

INSERT into PersonTransfer(EmpID,FirstName,LastName,Gender,DateofJoining,CurrentRegion,NewRegion)
SELECT Emp_ID,First_Name,Last_Name,Gender,Date_of_Joining,Region,"Capitol"
FROM person p where p.Gender='M' and (DATEDIFF(curdate(),Date_of_Joining)/365.2425)>20;


INSERT into PersonTransfer(EmpID,FirstName,LastName,Gender,DateofJoining,CurrentRegion,NewRegion)
SELECT Emp_ID,First_Name,Last_Name,Gender,Date_of_Joining,Region,"DC"
FROM person p where p.Gender='F' and (DATEDIFF(curdate(),Date_of_Joining)/365.2425)>10;  

    
select * from PersonTransfer;
    
END//
DELIMITER ;

call bulid_PersonTransfer;



