use SSD_ASSIGNMENT_2;

DELIMITER //
DROP function IF EXISTS `timezoneconvert`;
CREATE function `timezoneconvert`(input_date VARCHAR(30),src VARCHAR(5),dst VARCHAR(3))
returns datetime
deterministic
BEGIN
	declare ans datetime;
set ans= DATE_ADD(str_to_date(input_date,'%d-%m-%Y %H:%i:%s'), INTERVAL (select((select gmtoffset from time_zone where timezonecode=dst limit 1) - (select gmtoffset from time_zone where timezonecode=src limit 1))) second);
return ans;
END //
DELIMITER ;

 

