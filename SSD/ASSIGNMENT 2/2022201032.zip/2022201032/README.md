PREPROCESSING DONE ON empdetails.csv

PART I:Preprocessing done on column name :-- 
1. Emp ID to Emp_ID
2. Name Prefix to Name_Prefix
3. First Name to First_Name
4. Middle Initial to Middle_Initial
5. Last Name to Last_Name
6. E Mail to E_Mail
7. Father's Name to Fathers_Name
8. Mother's Name to Mothers_Name
9. Mother's Maiden Name to Mothers_Maiden_Name
10. Date of Birth to Date_of_Birth
11. Time of Birth to Time_of_Birth
12. Weight in Kgs. to Weight_in_Kgs
13. Date of Joining to Date_of_Joining
14. Last % Hike to Last_Hike
15. Place Name to Place_Name

PART II: Preprocessing done on data :--
1. Removed "%" from Last % Hike 
   Example - 17% to 17.
2. Converted Time of Birth from 12 Hours time format to 24 Hours time format
   Example - 12:18:49 AM to 00:18:49.
 
PREPROCESSING DONE ON timezone.csv
Added column names as zonename,countrycode, timezonecode, timestart, gmtoffset, dst. 

  
  
Question 1_1:
#How to Execute:
call build_hike2022

#How it works:
created procedure bulid_hike2022
inside procedure
	created table hike2022
	calculated required values
	considered only integer part for NewSalary
  	populated updated values into table hike2022
  	select * from hike2022
  	
#output:
Table hike2022



Question 1_2:
#How to Execute:
call bulid_PersonJoining

#How it works:
created procedure bulid_PersonJoining
inside procedure
	created table PersonJoining
	calculated required values 
  	populated updated values into table PersonJoining
  	select * from hike2022
  	
#output:
Table PersonJoining



Question 1_3:
#How to Execute:
call bulid_PersonTransfer

#How it works:
created procedure bulid_PersonTransfer
inside procedure
	created table PersonTransfer
	calculated required values 
	calculated Work Experience by considering only years.
  	populated updated values into table PersonTransfer
  	select * from PersonTransfer
  	
#output:
Table PersonTransfer



Question 2:
#How to Execute:
Give parameters to function : timezoneconvert 

#How it works:
created function timezoneconvert
inside function
step 1 :- selected the first occurence (limit 1) gmtoffset of dst from timezone table
step 2 :- selected the first occurence (limit 1) gmtoffset of src from timezone table
step 3 :- subtracted values found in step1 and step2 as step1-step2
step 4 :- got the time interval of step3 
step 5 :- converted input date (assuming input date as DD-MM-YYYY HH:MM:SS) to string and added the value which we got in step4.
step 6 :- returned answer to function.

#output:
converted time in format YYYY-MM-DD HH:MM:SS



Question 3:
#How to Execute:
Run sql query of q3.sql

#How it works:
selected No. Of Employee born between 00:00 hours to 08:00 hours ,
No. Of Employee born between 08:01 hours to 15:00 hours,
No. Of Employee born between 15:01 hours to 22:59 hours and 
applied INNER JOIN on these three queries to get our final output.

#output:
Table with employeeRegion and no. of employees born with in that particular time interval.




