Question 1:
Used functions and print statement to draw the desired figure.

How to Run?
In terminal : python3 pattern.py

Question 2:
Used pandas dataframe,csv and tabulate
Assumptions:
Each Entry inside “Address Directory” will store First_Name,Last_Name, Address, City, State, Zip, Contact number,Email_address.
For reading/loading entries from .csv file user will give filename of csv file and the file will be present in same folder as python script.
For Displaying “Address Directory” i am, using tabulate method.
for removing entries in directory user will give index which needs to be removed.
For updating entries in directory user will first give index on which the update has to be performed and then the attribute name and updated value.(user can only give one update at a time.)
for searching entries in directory user can give multiple Attribute(s) and value(s) and if all the entries match in the “Address Directory” then only output will be shown else an empty table will be printed.

How to Run?
In terminal : python3 address.py

Question 3:
Used MatPlotlib and math.
Printed Total distance and eucledian distance.
printed whole path in one go as a figure (i.e, not like a start point and end point with arrows).
Printed last position of person w.r.t origin.

Assumptions:
User will give only one unit of distance (i.e,cm or mm).
Seperater between Distance and Direction is comma(,).

How to Run?
In terminal : python3 map.py
