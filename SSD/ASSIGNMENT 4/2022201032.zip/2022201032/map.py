from matplotlib import pyplot as plt
import math
import numpy

n = int(input())

lst = []

x = [0]

y = [0]

sum = 0

lst_distance = []

lst_direction = []


for i in range(n):
    l = list(map(str, input().split(",")))

    tmp = l[0]
    tmp = tmp[:-2]
    u = float(tmp)
    lst_distance.append(u)

    v = l[1]
    lst_direction.append(v)

txt = "{xc:.2f},{yc:.2f}"
plt.text(0, 0, txt.format(xc=0, yc=0))


for k in range(0, n):
    if lst_direction[k] == "N":
        x.append(x[-1]+0)
        y.append(y[-1]+lst_distance[k])
        sum = sum+lst_distance[k]
        tmp2 = y[-1]
        tmp1 = x[-1]
        plt.text(tmp1, tmp2, txt.format(xc=tmp1, yc=tmp2))

    if lst_direction[k] == "S":
        x.append(x[-1]+0)
        y.append(y[-1]-lst_distance[k])
        sum = sum+lst_distance[k]
        tmp2 = y[-1]
        tmp1 = x[-1]
        plt.text(tmp1, tmp2, txt.format(xc=tmp1, yc=tmp2))

    if lst_direction[k] == "W":
        x.append(x[-1]-lst_distance[k])
        y.append(y[-1]+0)
        sum = sum+lst_distance[k]
        tmp2 = y[-1]
        tmp1 = x[-1]
        plt.text(tmp1, tmp2, txt.format(xc=tmp1, yc=tmp2))

    if lst_direction[k] == "E":
        x.append(x[-1]+lst_distance[k])
        y.append(y[-1]+0)
        sum = sum+lst_distance[k]
        tmp2 = y[-1]
        tmp1 = x[-1]
        plt.text(tmp1, tmp2, txt.format(xc=tmp1, yc=tmp2))

    if lst_direction[k] == "NE":
        x.append(x[-1]+(lst_distance[k]*0.7072))
        y.append(y[-1]+(lst_distance[k]*0.7072))
        sum = sum+lst_distance[k]
        tmp2 = y[-1]
        tmp1 = x[-1]
        plt.text(tmp1, tmp2, txt.format(xc=tmp1, yc=tmp2))

    if lst_direction[k] == "NW":
        x.append(x[-1]-(lst_distance[k]*0.7072))
        y.append(y[-1]+(lst_distance[k]*0.7072))
        sum = sum+lst_distance[k]
        tmp2 = y[-1]
        tmp1 = x[-1]
        plt.text(tmp1, tmp2, txt.format(xc=tmp1, yc=tmp2))

    if lst_direction[k] == "SE":
        x.append(x[-1]+(lst_distance[k]*0.7072))
        y.append(y[-1]-(lst_distance[k]*0.7072))
        sum = sum+lst_distance[k]
        tmp2 = y[-1]
        tmp1 = x[-1]
        plt.text(tmp1, tmp2, txt.format(xc=tmp1, yc=tmp2))

    if lst_direction[k] == "SW":
        x.append(x[-1]-(lst_distance[k]*0.7072))
        y.append(y[-1]-(lst_distance[k]*0.7072))
        sum = sum+lst_distance[k]
        tmp2 = y[-1]
        tmp1 = x[-1]
        plt.text(tmp1, tmp2, txt.format(xc=tmp1, yc=tmp2))

if x[-1] > 0:
    if y[-1] > 0:
        direction = "North-East"
    else:
        direction = "South-East"
elif x[-1] < 0:
    if y[-1] > 0:
        direction = "North-West"
    else:
        direction = "South-West"
elif x[-1] == 0:
    if y[-1] < 0:
        direction = "South"
    else:
        direction = "North"
elif y[-1] == 0:
    if x[-1] < 0:
        direction = "West"
    else:
        direction = "East"
elif x[-1] == 0 and y[-1] == 0:
    direction = "origin"


print("Total Distance - " + str(sum))


print("Euclidean distance - " +
      str(math.sqrt(((x[-1]-x[0])*(x[-1]-x[0]))+((y[-1]-y[0])*(y[-1]-y[0])))))

print("Direction w.r.t origin - " + str(direction))

print("End point co-ordinates - "+"("+str(x[-1])+","+str(y[-1])+")")

plt.plot(x, y)
plt.show()

