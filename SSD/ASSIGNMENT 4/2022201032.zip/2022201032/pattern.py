def fun_1():
    print("  ______")


def fun_2():
    print(" /      \\")


def fun_3():
    print("/        \\")


def fun_4():
    print("+--------+")


def fun_5():
    print("\\        /")


def fun_6():
    print(" \\______/")


def fun_7():
    print("|  STOP  |")


fun_1()
fun_2()
fun_3()
fun_4()
fun_1()
fun_2()
fun_3()
fun_5()
fun_6()
fun_5()
fun_6()
fun_4()
fun_1()
fun_2()
fun_3()
fun_7()
fun_5()
fun_6()
