import pandas as pd
from tabulate import tabulate
import csv


# update,remove nahi hua hai
 
first_name = []
last_name = []
address = []
city = []
state = []
zip = []
contact = []
email = []

cnt = 1

z = pd.DataFrame()

while 1:
    print("")
    print("Enter choice: ")
    print("1.Enter details from command prompt. ")
    print("2.Enter details from csv file. ")
    print("3.Display the directory on terminal. ")
    print("4.Remove entry from directory. ")
    print("5.Update entry from directory. ")
    print("6.Search for entry in the directory. ")
    print("")

    choice = int(input())

    if choice == 1:
        n = int(input("Enter number of entries - "))
        for i in range(n):
            print()
            n1 = str(input("Enter f_name : "))
            first_name.append(n1)

            n2 = str(input("Enter l_name : "))
            last_name.append(n2)

            n3 = str(input("Enter address : "))
            address.append(n3)

            n4 = str(input("Enter city : "))
            city.append(n4)

            n5 = str(input("Enter state : "))
            state.append(n5)

            n6 = str(input("Enter zip : "))
            zip.append(n6)

            n7 = str(input("Enter contact : "))
            contact.append(n7)

            n8 = str(input("Enter email : "))
            email.append(n8)

        y = {"First_Name": first_name, "Last_Name": last_name, "Address": address,
             "City": city, "State": state, "Zip": zip, "Contact_number": contact, "Email_address": email}

        z = z.append(pd.DataFrame(y), ignore_index=True)

    elif choice == 2:
        filenm = str(input("Enter csv file - "))
        csv_reader = pd.read_csv(filenm)
        z = z.append(csv_reader, ignore_index=True)

    elif choice == 3:
        print(tabulate(z, headers="keys", tablefmt="psql"))

    elif choice == 4:
        print(tabulate(z, headers="keys", tablefmt="psql"))
        print("Enter Index to be removed - ")
        sd = int(input())
        z = z.drop(sd)

        z.reset_index(drop=True, inplace=True)
        print("Removed Successfully !!!!!")

    elif choice == 5:
        print(tabulate(z, headers="keys", tablefmt="psql"))
        print("Enter Index to be updated - ")
        sd = int(input())

        print("Enter Attribute and value to be updated - ")
        l = list(map(str, input().split(" ")))
        col = l[0]
        val = l[1]

        z.loc[sd, [col]] = val

        print("Updated Successfully !!!!!")

    elif choice == 6:
        print("Enter Attribute(s) and value(s) to be searched - ")
        l = list(map(str, input().split(" ")))
        size = len(l)

        tmp = pd.DataFrame()
        tmp = z
        for i in range(0, size-1, 2):
            col = l[i]
            val = l[i+1]
            tmp = tmp[tmp[col] == val]

        print(tabulate(tmp, headers="keys", tablefmt="psql"))

    elif choice == 7:
        print("Bye!!")
        break

    else:
        print("Enter Valid Choice.")
